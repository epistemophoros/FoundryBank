# Icons

Place the module icon here as `foundrybank-icon.png`.

Recommended specifications:
- Size: 512x512 pixels
- Format: PNG with transparency
- Style: Should represent banking/financial theme

You can use a simple icon like:
- 🏦 Bank building
- 💰 Coins/money
- 💳 Credit card
- 📊 Financial chart

For now, the module will work without an icon, but it's recommended to add one for better presentation in the Foundry VTT module browser.

