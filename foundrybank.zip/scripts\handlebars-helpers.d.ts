/**
 * Handlebars Helpers for FoundryBank
 */
export declare function registerHandlebarsHelpers(): void;
